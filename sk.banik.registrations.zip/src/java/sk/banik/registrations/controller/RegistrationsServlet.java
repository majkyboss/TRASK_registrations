/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.banik.registrations.controller;

import java.io.IOException;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import sk.banik.registrations.entities.Registration;
import sk.banik.registrations.session.RegistrationFacade;

/**
 *
 * @author majky
 */
@WebServlet(name = "RegistrationsServlet",
        urlPatterns = {"/registrations"})
public class RegistrationsServlet extends HttpServlet {

    @EJB
    private RegistrationFacade regFacade;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        List<Registration> registrations = null;

        String agentIdString = request.getParameter("agent");
        String managerIdString = request.getParameter("manager");
        if (agentIdString != null) {
            short agentId = Short.parseShort(agentIdString);

            registrations = regFacade.findAllByAgent(agentId);
        } else if(managerIdString != null){
            short managerId = Short.parseShort(managerIdString);
            
            registrations = regFacade.findAllByManager(managerId);
        } else {
            // load registrations by parameters
            registrations = regFacade.findAll();
        }

        // set property for registrations view
        if (registrations != null && registrations.size() > 0) {
            request.setAttribute("registrations", registrations);
        }

        // forward to registrations view
        request.getRequestDispatcher("/WEB-INF/view/view_regs.jsp").forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
